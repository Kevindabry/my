Shirogane Kabi (白銀カビ) is a UTAU created by Kevindabry. Please read the terms and conditions.

----Terms and Conditions----
English---
Terms and Conditions for Using the Voice of Shirogane Kabi
1. Rights of Use and Distribution
The voice of Kabi is available for free use under the following terms:

Personal Use: The voice of Kabi can be used in personal projects, such as non-commercial songs or tests. The name of the character must be mentioned in the songs using the voice, but credit to the creator is not necessary. It is important that the character's name, Kabi, is mentioned as the voice used.
Commercial Use: The voice of Kabi should not be used for commercial purposes without explicit authorization. As the creator does not provide contact information, it will not be possible to authorize commercial use.
2. Modifications and Edits
The voice of Kabi can be modified under the following conditions:

Improvements: Modifications can be made to improve the voice, such as adjusting it to other programs like Vocaloid or SynthV. These modifications should be for enhancing the quality and not changing the character’s essence.
Transfer to Other Programs: The voice can be used and transferred to other programs, like Vocaloid, without needing permission, but always under these terms.
3. Limitations
It is strictly prohibited:

Use in Inappropriate Contexts: The voice of Kabi should not be used in projects or contexts that are inappropriate, offensive, or harmful, such as discriminatory, violent, or explicit content.
Selling the Voice: The voice is completely free and should never be sold. Any attempt to commercialize the voice without authorization will be considered a violation of the terms.
4. Distribution and Sharing

Free Distribution: If the voice of Kabi is shared in tutorials, download pages (such as Mediafire or similar websites), or distribution platforms, credit must be given to Kabi as the voice used, but it is not necessary to credit the creator in every song.
No Inappropriate Modifications: When sharing the voice, others should not be allowed to make modifications that change the character's personality or design without explicit permission.

日本語---
白銀カビの声に関する利用規約
1. 使用および配布権
カビンの声は、以下の条件のもとで無料で使用できます：

個人的な使用: カビの声は、個人的なプロジェクト（非商業的な歌やテストなど）で使用できます。声を使用する歌にはキャラクターの名前を記載する必要がありますが、創作者のクレジットは必要ありません。キャラクターの名前「アリカテ・ケイジン」を声として使用したことを明記することが重要です。
商業利用: カビの声は、明示的な許可なしに商業目的で使用することはできません。創作者が連絡先情報を提供しないため、商業利用の許可を出すことはできません。
2. 修正および編集
カビの声は以下の条件のもとで修正できます：

改善: 声の品質を向上させるための修正（例：VocaloidやSynthVなどの他のプログラムに調整すること）は可能です。これらの修正はキャラクターの本質を変更することなく、品質向上のために行うべきです。
他のプログラムへの移行: 声は、Vocaloidなどの他のプログラムに移行して使用することができますが、これらの条件を守っていれば許可を求める必要はありません。
3. 制限
以下は禁止されています：

不適切なコンテキストでの使用: カビの声は、不適切、攻撃的、または有害なコンテンツ（差別的、暴力的、または露骨な内容など）で使用することはできません。
声の販売: 声は完全に無料であり、販売することはできません。無許可で声を商業化しようとする試みは規約違反と見なされます。
4. 配布および共有

無料配布: カビの声がチュートリアルやダウンロードページ（Mediafireなど）や配布プラットフォームで共有される場合、声として使用されたキャラクター名「カビ」にクレジットを与える必要がありますが、各曲で創作者にクレジットを与える必要はありません。
不適切な修正の禁止: 声を共有する際、他の人がキャラクターの性格やデザインを変更するような修正を行うことは許可しません。



TikTok: @kevindabry